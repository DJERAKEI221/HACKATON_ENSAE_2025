admin_ui <- function(id) {
  ns <- NS(id) # Utiliser cette fonction NS pour préfixer les IDs
  
  div(class = "admin-container",
      # En-tête et styles améliorés
      tags$head(
        tags$style(HTML("
          .admin-container {
            max-width: 900px;
            margin: 2rem auto;
            padding: 0 1.5rem;
            font-family: 'Poppins', sans-serif;
          }
          .admin-header {
            background: linear-gradient(135deg, #3f51b5, #1a237e);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            text-align: center;
            position: relative;
            overflow: hidden;
          }
          .admin-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1NiIgaGVpZ2h0PSIxMDAiPgo8cmVjdCB3aWR0aD0iNTYiIGhlaWdodD0iMTAwIiBmaWxsPSIjMzAzZjlmIj48L3JlY3Q+CjxwYXRoIGQ9Ik0yOCA2NkwwIDUwTDAgMTZMMjggMEw1NiAxNkw1NiA1MEwyOCA2NkwyOCAxMDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzFhMjM3ZSIgc3Ryb2tlLXdpZHRoPSIyIj48L3BhdGg+CjxwYXRoIGQ9Ik0yOCAwTDI4IDY2TDAgNTBMMCA1MEwyOCA2NkwiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzI4M2E5YSIgc3Ryb2tlLXdpZHRoPSIxIj48L3BhdGg+Cjwvc3ZnPg==');
            opacity: 0.2;
          }
          .admin-title {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
            position: relative;
          }
          .admin-subtitle {
            font-size: 1.1rem;
            font-weight: 400;
            opacity: 0.9;
            margin-bottom: 0;
            position: relative;
          }
          .admin-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
            padding: 2rem;
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
          }
          .admin-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
          }
          .admin-card h3 {
            color: #303f9f;
            font-size: 1.6rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid rgba(63, 81, 181, 0.1);
          }
          .admin-warning {
            background: linear-gradient(135deg, #ffebee, #ffcdd2);
            border-left: 4px solid #f44336;
            color: #b71c1c;
            padding: 1.2rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
          }
          .admin-warning i {
            font-size: 1.5rem;
            margin-right: 1rem;
          }
          .admin-form-group {
            margin-bottom: 2rem;
          }
          .admin-form-label {
            font-weight: 600;
            color: #424242;
            margin-bottom: 0.5rem;
            display: block;
          }
          .admin-form-control {
            border: 2px solid #e0e6ff;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
          }
          .admin-form-control:focus {
            border-color: #3f51b5;
            box-shadow: 0 0 0 3px rgba(63, 81, 181, 0.15);
          }
          .admin-btn {
            font-weight: 600;
            padding: 0.8rem 2rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
          }
          .admin-btn-danger {
            background: linear-gradient(135deg, #f44336, #d32f2f);
            color: white;
            box-shadow: 0 4px 12px rgba(244, 67, 54, 0.3);
            cursor: pointer;
            opacity: 1;
            pointer-events: auto;
          }
          .admin-btn-danger:hover {
            background: linear-gradient(135deg, #d32f2f, #b71c1c);
            box-shadow: 0 6px 15px rgba(244, 67, 54, 0.4);
            transform: translateY(-2px);
          }
          .admin-btn-info {
            background: linear-gradient(135deg, #2196f3, #1976d2);
            color: white;
            box-shadow: 0 4px 12px rgba(33, 150, 243, 0.3);
            cursor: pointer;
            opacity: 1;
            pointer-events: auto;
          }
          .admin-btn-info:hover {
            background: linear-gradient(135deg, #1976d2, #0d47a1);
            box-shadow: 0 6px 15px rgba(33, 150, 243, 0.4);
            transform: translateY(-2px);
          }
          .admin-btn i {
            margin-right: 0.5rem;
            font-size: 1.1rem;
          }
          .admin-footer {
            text-align: center;
            margin-top: 3rem;
            font-size: 0.9rem;
            color: #757575;
          }
          .admin-footer a {
            color: #3f51b5;
            text-decoration: none;
          }
          
          /* Style pour le champ de confirmation */
          #reset_confirmation {
            border: 2px solid #e0e6ff;
            border-radius: 8px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            transition: all 0.3s ease;
          }
          
          #reset_confirmation:focus {
            border-color: #3f51b5;
            box-shadow: 0 0 0 3px rgba(63, 81, 181, 0.15);
            outline: none;
          }
          
          .admin-action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
          }
          
          .admin-card-section {
            margin-bottom: 1.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.08);
          }
          
          .admin-card-section:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
          }
          
          /* Override bootstrap pour les boutons Shiny */
          .btn-lg {
            padding: 0.8rem 2rem;
            font-size: 1.1rem;
            border-radius: 8px;
            font-weight: 600;
          }
          
          .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
          }
          
          .btn-danger:hover {
            background-color: #d32f2f;
            border-color: #d32f2f;
          }
          
          .btn-info {
            background-color: #2196f3;
            border-color: #2196f3;
          }
          
          .btn-info:hover {
            background-color: #1976d2;
            border-color: #1976d2;
          }
        "))
      ),
      
      # En-tête redessiné
      div(class = "admin-header",
          h1("Centre d'Administration", class = "admin-title"),
          p("Gestion et maintenance du système électoral", class = "admin-subtitle")
      ),
      
      # Module d'annonces
      announcementSystemUI("announcements"),
      
      # Carte principale simplifiée
      div(class = "admin-card",
          # Section d'exportation (maintenant en premier)
          div(class = "admin-card-section",
              h4("Exportation des données", 
                 tags$i(class = "fas fa-download", style = "margin-left: 10px; font-size: 1rem;")),
              
              p("Téléchargez l'ensemble des données de vote au format CSV pour les analyser dans d'autres applications."),
              
              div(class = "text-center mt-3",
                  downloadButton(ns("export_votes"), "Exporter tous les votes", 
                               class = "btn btn-info btn-lg",
                               icon = icon("file-export"))
              )
          ),
          
          # Section de réinitialisation (maintenant en second)
          div(class = "admin-card-section",
              # Avertissement
              div(class = "admin-warning",
                  tags$i(class = "fas fa-exclamation-triangle"),
                  div(
                    strong("Attention : Action irréversible"),
                    p(style = "margin-bottom: 0;", 
                      "Cette action supprimera tous les votes enregistrés dans la base de données. Cette opération est irréversible.")
                  )
              ),
              
              # Confirmation
              div(class = "admin-form-group",
                  tags$label("Confirmation de sécurité :", class = "admin-form-label"),
                  div(class = "mb-1", "Pour confirmer, tapez votre ", strong("identifiant administrateur"), " dans le champ ci-dessous :"),
                  textInput(ns("reset_confirmation"), NULL, 
                            placeholder = "Votre identifiant", 
                            width = "100%")
              ),
              
              # Bouton de réinitialisation
              div(class = "text-center mt-4",
                  actionButton(ns("reset_system"), "Procéder à la réinitialisation", 
                               class = "btn btn-danger btn-lg",
                               icon = icon("exclamation-triangle"))
              )
          )
      ),
      
      # Pied de page
      div(class = "admin-footer",
          p("Système d'administration • Élections ENSAE 2025", 
            br(),
            "Utilisez cet outil avec précaution")
      )
  )
} 