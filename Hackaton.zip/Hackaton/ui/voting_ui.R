voting_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(class = "voting-container",
        h2("Vote Électronique ENSAE", class = "section-title"),
        uiOutput(ns("position_selector")),
        uiOutput(ns("candidates_panel"))
    )
  )
} 