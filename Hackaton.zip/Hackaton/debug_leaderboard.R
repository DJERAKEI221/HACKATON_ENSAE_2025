# Script de débogage pour le classement

# Charger global.R pour accéder aux fonctions et données
source("global.R")

# Fonction de test pour simuler des votes
generate_test_votes <- function() {
  # Sélectionner 5 étudiants aléatoires pour simuler des votes
  if (nrow(students_df) >= 5) {
    sample_students <- students_df[sample(nrow(students_df), 5), ]
    
    cat("=== SIMULATION DE VOTES ===\n")
    cat("Étudiants sélectionnés pour les votes:\n")
    
    # Ajouter des votes pour chaque étudiant
    for (i in 1:nrow(sample_students)) {
      student <- sample_students[i, ]
      full_name <- get_full_name(student$Identifiant)
      
      # Simuler 1 à 3 votes AES
      aes_votes <- sample(1:3, 1)
      
      # Simuler 0 à 2 votes délégués
      delegate_votes <- sample(0:2, 1)
      
      cat(i, ". ", full_name, " (", student$Identifiant, ") - AES: ", aes_votes, ", Délégués: ", delegate_votes, "\n", sep="")
    }
  } else {
    cat("Pas assez d'étudiants dans le jeu de données pour simuler des votes\n")
  }
}

# Fonction simplifiée pour afficher le classement
display_leaderboard <- function() {
  cat("\n=== CLASSEMENT DES VOTANTS ===\n")
  
  # Vérifier si la fonction get_full_name fonctionne
  cat("Test de la fonction get_full_name:\n")
  if (nrow(students_df) > 0) {
    test_id <- students_df$Identifiant[1]
    test_name <- get_full_name(test_id)
    cat("- ID:", test_id, "-> Nom:", test_name, "\n")
    
    # Tester avec un admin
    admin_name <- get_full_name("admin1")
    cat("- ID: admin1 -> Nom:", admin_name, "\n")
    
    # Tester avec un ID invalide
    invalid_name <- get_full_name("invalid_id")
    cat("- ID: invalid_id -> Nom:", invalid_name, "\n")
  } else {
    cat("Aucun étudiant disponible pour tester get_full_name\n")
  }
  
  # Créer un classement de test
  cat("\nCréation d'un classement de test:\n")
  test_leaderboard <- list(
    list(
      name = "Étudiant Test 1",
      score = 300,
      classe = "AS1",
      aes_votes = 2,
      delegate_votes = 1,
      total_votes = 3
    ),
    list(
      name = "Étudiant Test 2",
      score = 200,
      classe = "AS2",
      aes_votes = 1,
      delegate_votes = 1,
      total_votes = 2
    ),
    list(
      name = "Étudiant Test 3",
      score = 100,
      classe = "AS3",
      aes_votes = 1,
      delegate_votes = 0,
      total_votes = 1
    )
  )
  
  # Afficher le classement
  for (i in 1:length(test_leaderboard)) {
    entry <- test_leaderboard[[i]]
    cat(i, ". ", entry$name, " (", entry$classe, ") - AES: ", entry$aes_votes, 
        ", Délégués: ", entry$delegate_votes, ", Total: ", entry$total_votes, 
        " - ", entry$score, " pts\n", sep="")
  }
}

# Exécuter les tests
cat("=== DÉBUT DES TESTS DE DÉBOGAGE ===\n\n")

# Vérifier que les données étudiants sont chargées
cat("Données étudiants: ", nrow(students_df), " entrées\n", sep="")

# Simuler des votes
generate_test_votes()

# Afficher le classement
display_leaderboard()

cat("\n=== FIN DES TESTS DE DÉBOGAGE ===\n") 