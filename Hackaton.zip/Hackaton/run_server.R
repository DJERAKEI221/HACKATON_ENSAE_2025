# Script pour lancer le serveur Shiny
shiny::runApp() 